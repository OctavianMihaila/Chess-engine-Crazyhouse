package main;

public enum PlaySide {BLACK, WHITE, NONE}
